void init_equipo(void);
char **hay_equipo(char *nom);
