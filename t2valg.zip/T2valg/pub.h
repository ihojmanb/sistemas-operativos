
#define VARON 0
#define DAMA  1

void ini_pub(void);
void entrar(int sexo);
void salir(int sexo);
