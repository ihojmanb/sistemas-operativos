agrego nSystem.h por rigor porque lo modifiqué agregando lo que indicaban en la tarea, pero no agregué nada de mi autoría 
